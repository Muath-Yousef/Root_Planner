# ربط Root Planner بوكلاء الذكاء الاصطناعي (REST + OpenAPI + MCP)

## 1. المعمارية

```
┌────────────┐  MCP (stdio)   ┌──────────────────┐   HTTP + Bearer   ┌──────────────────────────┐
│ Claude     │───────────────▶│ server/          │──────────────────▶│ server/launch.mjs        │
│ Claude Code│                │ mcp-server.mjs   │                   │  http-server.mjs (REST)  │
│ وكلاء محليون│                │ (غلاف بلا منطق)  │                   │  file-store.mjs          │
└────────────┘                └──────────────────┘                   │  src/api  ← محرك الاستوديو│
┌────────────┐  OpenAPI 3.1 / Function Calling                       │  (نفس قواعد الواجهة)      │
│ GPT, Gemini│──────────────────────────────────────────────────────▶│                          │
│ Grok, محلي │   GET /openapi.json · GET /tools · POST /tools/<name> └──────────────────────────┘
└────────────┘
```

- **الطبقة الأساسية** `src/api/*`: جدول مسارات واحد (`routes.ts`) يولّد كل شيء: مواصفة OpenAPI، تصاريح Function Calling (openai / anthropic / gemini / mcp)، وأوصاف أدوات MCP. لا توجد قاعدة أعمال مكرّرة؛ كل رفض يأتي من المحرك نفسه (`cablingValidator`, `employeeFactory`, `inspectorEdit`, `secretGuard`, `ssrfGuard`, …). ما يرفضه المحرك في الواجهة يرفضه هنا.
- **غلاف MCP** `server/mcp-server.mjs`: يقرأ الأدوات من `/openapi.json` (حقل `x-agent-tool`) ويمرّر الاستدعاءات عبر HTTP. لا يحتوي مساراً مبرمجاً يدوياً، فلا ينحرف عن الـ REST.
- **المخزن**: ملف JSON لكل مشروع بنفس صيغة تصدير الاستوديو (`<id>.json`)، فيمكن فتح أي مشروع بناه وكيل عبر **Import** في الواجهة، والعكس.

## 2. التشغيل السريع

```bash
npm ci
export ROOT_PLANNER_API_TOKEN="$(openssl rand -base64 32 | tr -d '=+/')"   # ≥ 16 محرفاً
npm run agent:api -- --port 8787        # REST على 127.0.0.1 (افتراضياً)
curl -s localhost:8787/healthz
```

خيارات `server/launch.mjs`:

| الخيار | الأثر |
|---|---|
| `--host <addr>` | عنوان الربط. أي عنوان غير loopback **يتطلب توكناً**. |
| `--port <n>` | المنفذ (الافتراضي 8787، و`0` لمنفذ حر). |
| `--data-dir <dir>` | مجلد المشاريع (الافتراضي `./.agent-projects`، مُتجاهَل في git). |
| `--read-only` | قراءة ومحاكاة فقط؛ كل تعديل يُرفض بـ `READ_ONLY`. |
| `--public-url <https-url>` | العنوان العام (وراء reverse proxy/نفق)؛ يدخل في `servers` بالـ OpenAPI وقائمة Host المسموحة. |
| `--allowed-host <name>` | Host إضافي مسموح (يتكرر). |
| `--no-auth` | تطوير محلي على loopback فقط. |
| `--print-openapi <file\|->` | يكتب مواصفة OpenAPI ويخرج (`npm run agent:openapi`). |

## 3. نموذج الأمان (default-deny)

| الضابط | التفاصيل |
|---|---|
| المصادقة | `Authorization: Bearer <token>`، مقارنة ثابتة الزمن، وقفل مؤقت بعد 20 فشلاً/دقيقة. `/healthz` و`/openapi.json` و`/tools` عامة عمداً (لا تحوي بيانات مشاريع). |
| DNS rebinding | قائمة Host مسموحة (loopback + `--public-url` + `--allowed-host`). |
| CSRF | لا CORS؛ أي طلب بترويسة `Origin` يُرفض. |
| المدخلات | `application/json` فقط، حد 4 MiB، مخطط AJV صارم لكل مسار، وأي وسيط غير معروف يُرفض مع قائمة المسموح. |
| التزامن | `If-Match` / `if_match` (etag) + قفل لكل مشروع؛ التعارض → `ETAG_MISMATCH`. |
| التراجع | آخر 20 نسخة لكل مشروع؛ `undo_last_change`. |
| الملفات | كتابة ذرية (temp + rename)، صلاحيات `0600`/`0700`، ولا يُحفظ مشروع لا يجتاز فحص Import الخاص بالاستوديو. |
| السجلات | تسجيل الطريقة والمسار والحالة فقط؛ لا أجسام ولا توكنات. الأخطاء غير المتوقعة تُسجَّل (الرسالة + 4 أسطر stack) ويرى العميل 500 عاماً. |
| غلاف MCP | الأدوات المدمّرة (`delete_project`, `import_project`) **مخفية افتراضياً**؛ `ROOT_PLANNER_MCP_READ_ONLY=1` يُبقي أدوات القراءة/المعاينة فقط؛ ويرفض إرسال التوكن عبر `http://` إلى مضيف غير loopback. |

توصية: شغّل خادم REST على loopback، ولا تعرضه خارجياً إلا خلف TLS (reverse proxy أو نفق) مع `--public-url` وتوكن طويل عشوائي. دوّر التوكن عند أي اشتباه بتسرّب.

## 4. الربط حسب العميل

### 4.1 Claude Desktop (MCP عبر stdio)

يتطلب أن يكون خادم REST شغّالاً (القسم 2). في `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "root-planner": {
      "command": "node",
      "args": ["/abs/path/Root_Planner/server/mcp-server.mjs"],
      "env": {
        "ROOT_PLANNER_API_URL": "http://127.0.0.1:8787",
        "ROOT_PLANNER_API_TOKEN": "<token>"
      }
    }
  }
}
```

### 4.2 Claude Code

```bash
claude mcp add root-planner \
  --env ROOT_PLANNER_API_URL=http://127.0.0.1:8787 \
  --env ROOT_PLANNER_API_TOKEN="$ROOT_PLANNER_API_TOKEN" \
  -- node /abs/path/Root_Planner/server/mcp-server.mjs
```

أو في `.mcp.json` للمشروع (بجانب خادم `pipeline` الموجود) مع `ROOT_PLANNER_API_TOKEN` من البيئة، دون كتابة التوكن داخل الملف المُلتزَم به.

متغيرات الغلاف: `ROOT_PLANNER_API_URL`، `ROOT_PLANNER_API_TOKEN`، `ROOT_PLANNER_MCP_READ_ONLY=1`، `ROOT_PLANNER_MCP_ALLOW_DESTRUCTIVE=1`.

الموارد (Resources): `rootplanner://guide`، `roles`، `cables`، `scenarios`، `projects`، وقوالب `rootplanner://projects/{project_id}/{summary|project|problems|diagram}`. المطالبات (Prompts): `design_organisation`، `review_project`.

### 4.3 ChatGPT (Custom GPT → Actions)

1. شغّل الخادم خلف HTTPS عام: `--public-url https://planner.example.com`.
2. في Actions: Import from URL → `https://planner.example.com/openapi.json`.
3. Authentication: API Key → Auth Type **Bearer** → التوكن.

حدود نصوص Actions (summary/description ≤ 300 محرف) مُطبَّقة باختبار. الإجراءات غير القابلة للعكس فقط تحمل `x-openai-isConsequential: true`.

### 4.4 Gemini / Grok / نماذج محلية (Function Calling)

```bash
curl -s "$URL/tools?format=gemini"   # أو openai | anthropic | mcp
```

- `openai`: صيغة `tools=[{type:"function",...}]` (تنطبق على أي خدمة متوافقة مع OpenAI، ومنها خوادم النماذج المحلية).
- `gemini`: تصاريح `functionDeclarations` بعد إزالة الكلمات غير المدعومة (`pattern`, `default`, `additionalProperties`, …).
- التنفيذ: عندما يُصدر النموذج نداءً باسم `X` وبوسائط `args`:

```bash
curl -s -X POST "$URL/tools/X" \
  -H "Authorization: Bearer $ROOT_PLANNER_API_TOKEN" -H 'content-type: application/json' \
  -d '<args كـ JSON>'
```

أعد جسم الاستجابة كما هو إلى النموذج: كل رفض يحمل `error.code` ثابتاً و`error.message` فيه الإصلاح المطلوب.

## 5. سير العمل الموصى به للوكيل

`get_agent_guide` ← `list_roles` ← `create_project` ← `get_project_summary` ← `preview_employee` / `check_cable` (محاكاة بلا تعديل) ← `add_employee` / `add_node` / `connect_nodes` ← `list_problems` حتى `errors = 0` ← `run_simulation` ← `get_bundle`. مرّر `if_match` في كل تعديل.

## 6. التحقق

```bash
npm run lint
npx vitest run tests/api.test.ts tests/agentServers.test.ts tests/fileStore.test.ts   # 47 اختباراً
npm test                                                                              # المجموعة الكاملة
```

فحص حي (عمليتان حقيقيتان): شغّل `agent:api` ثم اتصل بـ `server/mcp-server.mjs` بعميل MCP عبر stdio واستدعِ `get_project_summary`.

## 7. حدود معروفة

- **لم يُجرَّب** هنا ربط حي مع ChatGPT أو Gemini أو Grok؛ الأقسام 4.3–4.4 مبنية على تنسيقات تلك الواجهات كما هي موثقة، والمُتحقَّق منه فعلياً هو العقد (OpenAPI 3.1، صيغ التصاريح، `POST /tools/<name>`) وغلاف MCP عبر stdio.
- غلاف MCP يعمل بنقل **stdio** فقط (محلي). لعملاء MCP البعيدين يلزم نقل HTTP قابل للبث وطبقة OAuth، وهما خارج هذا النطاق.
- خادم REST يعمل في عملية واحدة؛ القفل لكل مشروع داخل العملية فقط، فلا تشغّل نسختين على نفس `--data-dir`.
- حدّ المعدل بالذاكرة (600 طلب/دقيقة لكل عنوان) وليس بديلاً عن حماية reverse proxy.
